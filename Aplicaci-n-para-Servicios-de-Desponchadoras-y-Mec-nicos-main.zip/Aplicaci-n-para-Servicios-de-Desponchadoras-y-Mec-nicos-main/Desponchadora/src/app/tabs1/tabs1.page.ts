import { Component } from '@angular/core';

@Component({
  selector: 'app-tabs1',
  templateUrl: 'tabs1.page.html',
  styleUrls: ['tabs1.page.scss']
})
export class Tabs1Page {

  constructor() {}

}
