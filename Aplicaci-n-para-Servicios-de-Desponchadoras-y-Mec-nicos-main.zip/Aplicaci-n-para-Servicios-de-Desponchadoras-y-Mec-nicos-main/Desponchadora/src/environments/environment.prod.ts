export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyAQIZkFwz_DVPl4tz0NCpoAJBxaiLxRC9E",
    authDomain: "autohelp-7e602.firebaseapp.com",
    projectId: "autohelp-7e602",
    storageBucket: "autohelp-7e602.appspot.com",
    messagingSenderId: "411585384693",
    appId: "1:411585384693:web:da5767cc98db7b3d1075bc",
    measurementId: "G-B722QMZ0NE"
  }
};
